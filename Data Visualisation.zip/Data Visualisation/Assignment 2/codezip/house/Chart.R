
# Replace 'path_to_your_geojson_file.geojson' with your actual file path
geojson_data <- st_read('C:/Users/ashfaq/Desktop/YO.geojson')

# Replace 'your_data_file.csv' with your actual file path
data <- EPC_clean


# Extract the first part of the postcode in the CSV data
data$name <- substr(data$name, 1, 4)  # Adjust this if needed


# Replace 'id_column' with the common ID column name in both datasets
geojson_data <- merge(geojson_data, data, by = "name")

merged_data <-geojson_data

Map <- ggplot(data = merged_data) +
  geom_sf(aes(fill = ENVIRONMENT_IMPACT_CURRENT), linewidth = 0, alpha = 0.9) +
  geom_text(
    aes(label = name, geometry = geometry),
    stat = "sf_coordinates",
    size = 3,
    color = "black"
  ) +
  theme_void() +
  scale_fill_viridis_c(
    trans = "log", breaks = c(1, 5, 10, 20, 50, 100),
    name = "Environmental Impact",
    guide = guide_legend(
      keyheight = unit(3, units = "mm"),
      keywidth = unit(10, units = "mm"),
      label.position = "bottom",
      title.position = "top",
      nrow = 1
    )
  ) +
  labs(
    title = "Environmental Impact by Postcode in York",
    subtitle = "Current Environmental Impact per Postcode"
  ) +
  theme(
    text = element_text(color = "#22211d"),
    plot.background = element_rect(fill = "#f5f5f2", color = NA),
    panel.background = element_rect(fill = "#f5f5f2", color = NA),
    legend.background = element_rect(fill = "#f5f5f2", color = NA),
    plot.title = element_text(
      size = 20, hjust = 0.01, color = "#4e4d47",
      margin = margin(
        b = -0.1, t = 0.4, l = 2,
        unit = "cm"
      )
    ),
    plot.subtitle = element_text(
      size = 15, hjust = 0.01,
      color = "#4e4d47",
      margin = margin(
        b = -0.1, t = 0.43, l = 2,
        unit = "cm"
      )
    ),
    plot.caption = element_text(
      size = 10,
      color = "#4e4d47",
      margin = margin(
        b = 0.3, r = -99, t = 0.3,
        unit = "cm"
      )
    ),
    legend.position = c(0.7, 0.09)
  )

